const { Sequelize } = require("sequelize");
const sequelize = require("../connection");

// Define a model for the Visitante table
const Visitante = sequelize.define("Visitante", {
  nome: Sequelize.STRING,
  deOndeVeio: Sequelize.STRING,
  redeSocial: Sequelize.STRING,
  igrejaAnterior: Sequelize.STRING,
  endereco: Sequelize.STRING,
  telefone: Sequelize.STRING,
  dataBatismo: Sequelize.DATE,
});

Visitante.sync({ force: false })

module.exports = Visitante;