const Visitante = require("../models/VisitanteModel");

const router = require("express").Router();

router.post("/", async (req, res) => {
  try {
    if (!req.body.nome || !req.body.deOndeVeio || !req.body.redeSocial) {
      res.status(400).json({ error: "Missing required fields" });
    } else {
      const visitante = await Visitante.create(req.body);
      res.redirect("/app/visitantes");
    }
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.get("/", async (req, res) => {
  try {
    const visitantes = await Visitante.findAll();
    res.json(visitantes);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.get("/:id", async (req, res) => {
  try {
    if (!req.params.id) {
      res.status(400).json({ error: "Missing ID parameter" });
    } else {
      const visitante = await Visitante.findByPk(req.params.id);
      if (visitante) {
        res.json(visitante);
      } else {
        res.status(404).json({ error: "Visitante not found" });
      }
    }
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.put("/:id", async (req, res) => {
  try {
    if (!req.params.id) {
      res.status(400).json({ error: "Missing ID parameter" });
    } else if (!req.body.nome || !req.body.deOndeVeio || !req.body.redeSocial) {
      res.status(400).json({ error: "Missing required fields" });
    } else {
      const visitante = await Visitante.findByPk(req.params.id);
      if (visitante) {
        const updatedVisitante = await visitante.update(req.body);
        res.json(updatedVisitante);
      } else {
        res.status(404).json({ error: "Visitante not found" });
      }
    }
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    if (!req.params.id) {
      res.status(400).json({ error: "Missing ID parameter" });
    } else {
      const visitante = await Visitante.findByPk(req.params.id);
      if (visitante) {
        await visitante.destroy();
        res.json({ message: "Visitante deleted successfully" });
      } else {
        res.status(404).json({ error: "Visitante not found" });
      }
    }
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

module.exports = router;
